#include <iostream>

using namespace std;

int main(){
    int inp_1, inp_2, a;
    cout << "hi" << endl;
    cin >> inp_1;
    cin >> inp_2;
    inp_1 = abs(inp_1);
    inp_2 = abs(inp_2);
    a = inp_1 + inp_2;
    cout << a;
    return 0;
}