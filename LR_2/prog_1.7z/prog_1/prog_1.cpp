#include <iostream>

using namespace std;

int main(){
    int inp, a, b, c;
    cout << "hi";
    cin >> inp;
    a = inp % 10;
    b = (inp % 100) / 10;
    c = inp / 100;
    cout << c << a << b;
    return 0;
}